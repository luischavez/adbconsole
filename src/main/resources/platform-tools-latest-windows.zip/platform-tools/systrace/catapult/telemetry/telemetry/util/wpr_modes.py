# Copyright 2012 The Chromium Authors. All rights reserved.
# Use of this source code is governed by a BSD-style license that can be
# found in the LICENSE file.
WPR_APPEND = 'wpr-append'
WPR_OFF = 'wpr-off'
WPR_RECORD = 'wpr-record'
WPR_REPLAY = 'wpr-replay'
